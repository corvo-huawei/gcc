<!--
For bugs, paste output from your clipboard after running :ALEInfoToClipboard
here. If that doesn't work for some reason, try running :ALEInfo and copying
the output from that here instead. If everything is broken, run around in
circles and scream.

READ THIS -> If you are experiencing a bug where ALE is not correctly parsing
the output of commands, set g:ale_history_log_output to 1, and run ALE again,
and then :ALEInfo should include the full output of each command which ran.

Whatever the case, describe the your issue here.
-->
