# evervim.vim

## description:
edit evernote on vim.

## requires:
* python
* the "markdown" package for python
* vim with +python

If your vim was compiled with +python, `:echo has('python')` will return 1.

